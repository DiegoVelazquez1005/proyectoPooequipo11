/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectopoo;

import java.util.ArrayList;

/**
 *
 * @author velaz
 */
public class ProyectoPOO {
    public static void main(String[] args) {
        Acceso principal = new Acceso();
        principal.setVisible(true);
    }
    
}

